<template>
  <div class="navbar bg-base-100">
    <div class="flex-1">
      <a class="btn bg-orange-600 text-black normal-case text-xl"
        >آموزشگاه نیلوفر</a
      >
    </div>
    <div class="flex-none">
      <ul class="menu menu-horizontal px-1">
        <li><a @click="gotoaboutus">درباره ما</a></li>
        <li><a @click="gotocourse">دروس</a></li>
        <li><a @click="gotosignup">ثبت نام</a></li>
        <li><a @click="gotohome">خانه</a></li>
      </ul>
    </div>
  </div>
  <div class="hero min-h-screen bg-base-200">
    <div class="hero-content flex-col lg:flex-row">
      <img src="..\assets\image.png" class="rounded-lg w-5/6" />
      <div style="direction: rtl">
        <h1 class="text-5xl font-bold">آموزش کودکان و نوجوانان در هر سنی</h1>
        <br />
        <h3 class="text-4xl font-bold">آموزش را تضمین کنید</h3>
        <p class="py-6">
          با سیستم آموزشی ما آموزش کودکان خود را تضمین کنید با سیستم آموزشی ما
          آموزش کودکان خود را تضمین کنید با سیستم آموزشی ما آموزش کودکان خود را
          تضمین کنید با سیستم آموزشی ما آموزش کودکان خود را تضمین کنید
        </p>
        <button class="btn btn-primary btn-wide ml-6" @click="gotocourse">تماشای دورس</button>
        <button class="btn btn-accent btn-wide" @click="gotosignup">
          ثبت نام
        </button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "HomePage",
  methods: {
    gotohome() {
      this.$router.push("/home");
    },
    gotosignup() {
      this.$router.push("/signup");
    },
    gotocourse() {
      this.$router.push("/courses");
    },
    gotoaboutus(){
        this.$router.push("/aboutus");
    }
  },
};
</script>
