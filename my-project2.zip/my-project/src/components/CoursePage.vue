<script>
export default {
  name: "coursePage",
  methods: {
    gotohome() {
      this.$router.push("/home");
    },
    gotosignup() {
      this.$router.push("/signup");
    },
    gotocourse() {
      this.$router.push("/courses");
    },
    gotoaboutus(){
        this.$router.push("/aboutus");
    }
  },
};
</script>

<template>
  <div class="navbar bg-base-100">
    <div class="flex-1">
      <a class="btn bg-orange-600 text-black normal-case text-xl"
        >آموزشگاه نیلوفر</a
      >
    </div>
    <div class="flex-none">
      <ul class="menu menu-horizontal px-1">
        <li><a @click="gotoaboutus">درباره ما</a></li>
        <li><a @click="gotocourse">دروس</a></li>
        <li><a @click="gotosignup">ثبت نام</a></li>
        <li><a @click="gotohome">خانه</a></li>
      </ul>
    </div>
  </div>
  <div class="grid grid-cols-4 m-10">
    <div class="card w-96 bg-base-100 shadow-xl">
      <figure>
        <img src="../assets/math.jpg" alt="Shoes" />
      </figure>
      <div class="card-body" style="direction: rtl">
        <h2 class="card-title">ریاضی</h2>
        <p>تدریس توسط بهترین مدرس کنکور</p>
        <div class="card-actions justify-end">
          <button class="btn btn-primary" @click="gotosignup">ثبت نام</button>
        </div>
      </div>
    </div>
    <div class="card w-96 bg-base-100 shadow-xl">
      <figure>
        <img src="../assets/biology.jpg" alt="Shoes" />
      </figure>
      <div class="card-body" style="direction: rtl">
        <h2 class="card-title">زیست</h2>
        <p>صفر تا صد زیست کنکور در یک دوره آموزشی</p>
        <div class="card-actions justify-end">
          <button class="btn btn-primary" @click="gotosignup">ثبت نام</button>
        </div>
      </div>
    </div>
    <div class="card w-96 bg-base-100 shadow-xl">
      <figure>
        <img src="../assets/chemistry.jpeg" alt="Shoes" />
      </figure>
      <div class="card-body" style="direction: rtl">
        <h2 class="card-title">شیمی</h2>
        <p>میخوای شیمی رو صد بزنی ؟<br />ثبت نام کن!</p>
        <div class="card-actions justify-end">
          <button class="btn btn-primary" @click="gotosignup">ثبت نام</button>
        </div>
      </div>
    </div>
    <div class="card w-96 bg-base-100 shadow-xl">
      <figure>
        <img src="../assets/physics.jpg" alt="Shoes" />
      </figure>
      <div class="card-body" style="direction: rtl">
        <h2 class="card-title">فیزیک</h2>
        <p>فیزیک کنکور رو مثل آب قورت بده</p>
        <div class="card-actions justify-end">
          <button class="btn btn-primary" @click="gotosignup">ثبت نام</button>
        </div>
      </div>
    </div>
  </div>
</template>
