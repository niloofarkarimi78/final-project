<template>
  <div class="navbar bg-base-100">
    <div class="flex-1">
      <a class="btn bg-orange-600 text-black normal-case text-xl"
        >آموزشگاه نیلوفر</a
      >
    </div>
    <div class="flex-none">
      <ul class="menu menu-horizontal px-1">
        <li><a @click="gotoaboutus">درباره ما</a></li>
        <li><a @click="gotocourse">دروس</a></li>
        <li><a @click="gotosignup">ثبت نام</a></li>
        <li><a @click="gotohome">خانه</a></li>
      </ul>
    </div>
  </div>
  <div class="hero min-h-screen bg-base-200">
    <div class="hero-content flex-col lg:flex-row-reverse">
      <div class="text-center lg:text-right" style="direction: rtl">
        <h1 class="text-5xl font-bold">همین الان ثبت نام کنید!</h1>
        <p class="py-6 text-xl">
          همین الان میتوانید با پر کردن فرم ثبتنام از تخفیفات ما برخوردار شوید.
          کافیست همین الان فرم را پر کنید تا کارشناسان ما در اصرع وقت با شما
          تماس بگیرند
        </p>
      </div>
      <div
        class="card flex-shrink-0 w-full max-w-sm shadow-2xl bg-base-100"
        style="direction: rtl"
      >
        <div class="card-body">
          <div class="form-control">
            <label class="label">
              <span class="label-text">ایمیل</span>
            </label>
            <input
              type="text"
              placeholder="ایمیل"
              class="input input-bordered"
            />
          </div>
          <div class="form-control">
            <label class="label">
              <span class="label-text">نام کاربری</span>
            </label>
            <input
              type="text"
              placeholder="نام کاربری"
              class="input input-bordered"
            />
          </div>
          <div class="form-control">
            <label class="label">
              <span class="label-text">شماره تلفن</span>
            </label>
            <input
              type="text"
              placeholder="شماره تلفن"
              class="input input-bordered"
            />
          </div>
          <div class="form-control">
            <label class="label">
              <span class="label-text">گذرواژه</span>
            </label>
            <input
              type="text"
              placeholder="گذرواژه"
              class="input input-bordered"
            />
          </div>
          <div class="form-control mt-6">
            <button class="btn btn-primary" @click="showAlert">ثبت نام</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "signupPage",
  methods: {
    gotohome() {
      this.$router.push("/home");
    },
    gotosignup() {
      this.$router.push("/signup");
    },
    gotocourse() {
      this.$router.push("/courses");
    },
    gotoaboutus() {
      this.$router.push("/aboutus");
    },
    showAlert(){
      alert('ثبت نام با موفقیت انجام شد!')
    }
  },
};
</script>
