<script>
export default {
  name: "aboutUs",
  methods: {
    gotohome() {
      this.$router.push("/home");
    },
    gotosignup() {
      this.$router.push("/signup");
    },
    gotocourse() {
      this.$router.push("/courses");
    },
    gotoaboutus() {
      this.$router.push("/aboutus");
    },
  },
};
</script>

<template>
  <div class="navbar bg-base-100">
    <div class="flex-1">
      <a class="btn bg-orange-600 text-black normal-case text-xl"
        >آموزشگاه نیلوفر</a
      >
    </div>
    <div class="flex-none">
      <ul class="menu menu-horizontal px-1">
        <li><a @click="gotoaboutus">درباره ما</a></li>
        <li><a @click="gotocourse">دروس</a></li>
        <li><a @click="gotosignup">ثبت نام</a></li>
        <li><a @click="gotohome">خانه</a></li>
      </ul>
    </div>
  </div>
  <div class="grid mt-96">
    <div class="stats shadow place-self-center" style="direction: rtl;">
      <div class="stat">
        <div class="stat-figure text-primary"></div>
        <div class="stat-title">تعداد دانش آموزان</div>
        <div class="stat-value text-primary">2 هزار نفر</div>
        <div class="stat-desc">21% بیشتر از  پارسال</div>
      </div>

      <div class="stat">
        <div class="stat-figure text-secondary"></div>
        <div class="stat-title">دیده شدن درس ها</div>
        <div class="stat-value text-secondary">6 هزار ساعت</div>
        <div class="stat-desc">24% بیشتر از دوره قبل</div>
      </div>

      <div class="stat">
        <div class="stat-value">86%</div>
        <div class="stat-title">دانش آموزان با رتبه زیر 1000</div>
        <div class="stat-desc text-secondary">50% بیشتر از پارسال</div>
      </div>
    </div>
  </div>
</template>
