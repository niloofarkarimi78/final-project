 <template>
  
  <router-view/>
  
</template>

<script>
// import Homepage from './components/homepage.vue';

// import SignUpPage from './components/signUpPage.vue';

export default {
  name: 'App',
  components: {
    // Homepage,
    // SignUpPage
}
}
</script>

<style>

</style> 

