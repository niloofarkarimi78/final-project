import { createRouter, createWebHistory } from "vue-router";
import Homepage from "../components/homepage.vue";
import SignUpPage from "../components/signUpPage.vue";
import CoursePage from '../components/CoursePage.vue';
import AboutUsPage from '../components/aboutusPage.vue';

const routes = [
  {
    path: "/",
    redirect: "/home",
  },
  {
    path: "/home",
    name: "home",
    component: Homepage,
  },
  {
    path: "/signup",
    name: "signup",
    component: SignUpPage
  },
  {
    path: "/courses",
    name: "course",
    component: CoursePage
  },
  {
    path: "/aboutus",
    name: "aboutus",
    component: AboutUsPage
  },
];

export const router = createRouter({
  history: createWebHistory(),
  routes,
});
